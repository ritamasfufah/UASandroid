<form action="tambah.php" method="post">
<input type="text" name="nama">
<br>
<input type="text" name="kelas">
<br>
<input type="text" name="nik">
<br>
<input type="text" name="jam">
<br>
<input type="submit">
</form>